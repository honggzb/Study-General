# r3f-3d-text-effect

![3D-text-effect-thumbnail](https://img.youtube.com/vi/jIkn9dLBfNc/maxresdefault.jpg?w)

[Video tutorial](https://youtu.be/jIkn9dLBfNc)

[Starter pack](https://github.com/wass08/r3f-vite-final/)

Camping Asset Collection by Alex Safayan [CC-BY](https://creativecommons.org/licenses/by/3.0/) via [Poly Pizza](https://poly.pizza/m/3nj59_uuCbM)
