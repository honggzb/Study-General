import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { DataGeneratorService } from './data-generator.service';
import { Employee } from './employee';
import { List } from 'immutable';

const NUM_RANGE: [number, number] = [25, 31];

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <main class="flex justify-center space-x-36 mt-8">
      <app-employee-list
        [employees]="sales"
        (add)="sales = add(sales, $event)"
        (remove)="sales = remove(sales, $event)"
      />
      <app-employee-list
        [employees]="techs"
        (add)="techs = add(techs, $event)"
        (remove)="techs = remove(techs, $event)"
      />
    </main>
  `,
  styleUrls: ['./app.component.css'],
  imports: [CommonModule, EmployeeListComponent],
})
export class AppComponent {
  generator = inject(DataGeneratorService);

  sales = List(this.generator.generate([0, 70], NUM_RANGE));
  techs = List(this.generator.generate([70, 140], NUM_RANGE));

  add(list: List<Employee>, name: string) {
    return list.unshift({ name, rand: this.generator.rand(NUM_RANGE) });
  }

  remove(list: List<Employee>, item: Employee) {
    return list.splice(list.indexOf(item), 1);
  }
}
