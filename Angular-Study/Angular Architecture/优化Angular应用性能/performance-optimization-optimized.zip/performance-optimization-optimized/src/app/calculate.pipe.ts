import { Pipe, PipeTransform } from '@angular/core';
import memo from 'memo-decorator';

function fibonacci(n: number): number {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

@Pipe({
  name: 'calculate',
  standalone: true,
  pure: true,
})
export class CalculatePipe implements PipeTransform {
  @memo()
  transform(value: number, ...args: unknown[]): number {
    return fibonacci(value);
  }
}
