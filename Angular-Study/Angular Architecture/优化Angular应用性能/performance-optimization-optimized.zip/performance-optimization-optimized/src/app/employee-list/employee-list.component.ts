import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Employee } from '../employee';
import { FormsModule } from '@angular/forms';
import { ListComponent } from '../list/list.component';
import { List } from 'immutable';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  imports: [CommonModule, FormsModule, ListComponent],
})
export class EmployeeListComponent {
  @Input({ required: true }) employees!: List<Employee>;
  @Output() add: EventEmitter<string> = new EventEmitter();
  @Output() remove: EventEmitter<Employee> = new EventEmitter();

  name: string = '';

  handleKeyUp($event: KeyboardEvent) {
    if ($event.key === 'Enter' && this.name !== '') {
      this.add.emit(this.name);
      this.name = '';
    }
  }
}
