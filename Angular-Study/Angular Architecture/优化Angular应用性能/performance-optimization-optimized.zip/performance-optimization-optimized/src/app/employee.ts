export interface Employee {
  name: string;
  rand: number;
}
