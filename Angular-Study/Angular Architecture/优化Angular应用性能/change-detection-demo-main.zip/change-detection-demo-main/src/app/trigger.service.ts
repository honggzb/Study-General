import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TriggerService {
  private data = new BehaviorSubject('');
  data$ = this.data.asObservable();

  trigger() {
    this.data.next(this.data.getValue() + '-');
  }
}
