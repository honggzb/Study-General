import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardBaseComponent } from './card-base.component';

@Component({
  selector: 'app-v-card12',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #element class="card w-full border-2 border-solid bg-white">
      {{ touch }}
      <div class="card-body">
        <h2 class="card-title font-mono">Card 1-2 (Default)</h2>
        <div class="card-actions justify-end">
          <button class="btn" (click)="checking = !checking">Click</button>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class VCard12Component extends CardBaseComponent {
  @Input() obj: { title: string } = { title: '' };
  checking = false;
}
