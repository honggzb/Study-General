import {
  ChangeDetectionStrategy,
  Component,
  Input,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardBaseComponent } from './card-base.component';
import { TriggerService } from '../trigger.service';

@Component({
  selector: 'app-v-card13',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #element class="card w-full border-2 border-solid bg-white">
      {{ touch }}
      <div class="card-body">
        <h2 class="card-title font-mono">Card 1-3 (OnPush & Async Pipe)</h2>
        <p>{{ this.triggerService.data$ | async }}</p>
        <div class="card-actions justify-end">
          <button class="btn" (click)="checking = !checking">Click</button>
        </div>
      </div>
    </div>
  `,
  styles: [],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VCard13Component extends CardBaseComponent {
  @Input() obj: { title: string } = { title: '' };
  triggerService = inject(TriggerService);

  checking = false;
}
