import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardBaseComponent } from './card-base.component';

@Component({
  selector: 'app-c-card22',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #element class="card w-full border-2 border-dashed bg-white">
      {{ touch }}
      <div class="card-body">
        <h2 class="card-title font-mono">Content 1-2 (Default)</h2>
        <div class="card-actions justify-end">
          <button class="btn" (click)="checking = !checking">Click</button>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class CCard22Component extends CardBaseComponent {
  @Input() obj: { title: string } = { title: '' };
  checking = false;
}
