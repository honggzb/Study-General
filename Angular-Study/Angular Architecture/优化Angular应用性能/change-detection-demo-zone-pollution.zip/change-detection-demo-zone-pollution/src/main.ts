import {
  bootstrapApplication,
  enableDebugTools,
} from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
// import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
// import { ApplicationRef } from '@angular/core';

bootstrapApplication(AppComponent, appConfig)
  .then((m) => enableDebugTools(m.components[0]))
  .catch((err) => console.error(err));

// platformBrowserDynamic()
//   .bootstrapModule(AppModule)
//   .then((m) => enableDebugTools(m.injector.get(ApplicationRef).components[0]))
//   .catch((err) => console.error(err));
