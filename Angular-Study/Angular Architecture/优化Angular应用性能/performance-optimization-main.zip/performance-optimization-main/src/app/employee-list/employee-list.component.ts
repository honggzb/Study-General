import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Employee } from '../employee';
import { FormsModule } from '@angular/forms';

function fibonacci(n: number): number {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent {
  @Input({ required: true }) employees: Employee[] = [];
  @Output() add: EventEmitter<string> = new EventEmitter();
  @Output() remove: EventEmitter<Employee> = new EventEmitter();

  name = '';

  handleKeyUp($event: KeyboardEvent) {
    if ($event.key === 'Enter') {
      this.add.emit(this.name);
      this.name = '';
    }
  }

  calculate(n: number) {
    console.log('Recalculating fibonacci...');
    return fibonacci(n);
  }
}
