declare module 'mf/HiModule';
