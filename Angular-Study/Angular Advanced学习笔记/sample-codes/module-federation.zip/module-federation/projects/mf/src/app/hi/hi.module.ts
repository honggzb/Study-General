import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HiRoutingModule } from './hi-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HiRoutingModule
  ]
})
export class HiModule { }
