import {Component} from '@angular/core';
import {SwPush, SwUpdate} from "@angular/service-worker";
import {filter, timer} from "rxjs";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'service-worker';

  constructor(swUpdate: SwUpdate, swPush: SwPush) {
    swUpdate.versionUpdates.pipe(
      filter((event) => event.type === 'VERSION_READY'))
      .subscribe(() => {
        if (confirm('New version for the app is available. Do you want to reload?')) {
          document.location.reload();
        }
      });

    // swPush.messages.subscribe(console.log);

    Notification.requestPermission().then(permissions => {
      if (permissions === 'granted') {
        console.log('Show notifications');
      }
    })

    // {
    //   "notification": {
    //     "title": "Angular",
    //     "body": "Test push notifications",
    //     "icon": "http://icon/url",
    //     "click_action": "http://navigation-link"
    //   }
    // }


    // timer(1000 * 60 * 60 * 20).subscribe(() => {
    //   swUpdate.checkForUpdate().then()
    // })
  }
}
