import {Component, OnDestroy} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {
  counter = 0;
  bigInt = 0;
  worker!: Worker;

  constructor() {
    setInterval(() => {
      this.counter += 1;
    }, 100);
  }


  setBigInt(): void {
    this.worker = new Worker(new URL('./big-int.worker', import.meta.url));

    this.worker.postMessage('test');

    this.worker.addEventListener('message', ({data}) => {
      this.bigInt = data;
    })
  }

  ngOnDestroy(): void {
    this.worker.terminate();
  }
}
