/// <reference lib="webworker" />

import {setBigInt} from "./big-int";

addEventListener('message', ({ data }) => {
  const bigInt = setBigInt();
  postMessage(bigInt);
});
