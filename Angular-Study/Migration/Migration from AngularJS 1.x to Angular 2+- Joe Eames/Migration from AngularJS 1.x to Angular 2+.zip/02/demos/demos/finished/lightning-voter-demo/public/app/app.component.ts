import { Component } from "@angular/core";

@Component({
  selector: 'my-app',
  template: `
    <div class="ng-view"></div>
  `
})
export class AppComponent {}