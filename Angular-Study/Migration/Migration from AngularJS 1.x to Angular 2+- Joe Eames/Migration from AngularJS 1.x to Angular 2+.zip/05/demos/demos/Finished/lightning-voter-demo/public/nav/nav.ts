angular.module('app').component('nav', {
  templateUrl: './nav.html',
  bindings: {
  },
  controller: function(currentIdentity, unreviewedSessionCount) {
    
    this.currentUser = currentIdentity.currentUser;
    
    unreviewedSessionCount.updateUnreviewedSessionCount();
    this.unreviewedSessionCount = unreviewedSessionCount;
    
  }
});