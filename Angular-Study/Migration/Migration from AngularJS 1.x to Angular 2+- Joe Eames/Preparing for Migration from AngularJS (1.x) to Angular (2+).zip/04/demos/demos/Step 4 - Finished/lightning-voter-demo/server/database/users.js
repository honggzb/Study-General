var users = [
  {id: 1, email: 'joe@joe.com', password: 'pass', firstName: 'Joe', lastName: 'Eames', isAdmin: true},
  {id: 2, email: 'bob@bob.com', password: 'pass', firstName: 'Bob', lastName: 'Smith'}
]

module.exports = users;