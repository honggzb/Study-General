import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { AppComponent } from './app.component';
import { DragComponent } from './drag/drag.component';
import { SortListComponent } from './sort-list/sort-list.component';
import { TransferItemsListsComponent } from './transfer-items-lists/transfer-items-lists.component';

@NgModule({
  declarations: [
    AppComponent,
    DragComponent,
    SortListComponent,
    TransferItemsListsComponent
  ],
  imports: [
    BrowserModule,
    DragDropModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
