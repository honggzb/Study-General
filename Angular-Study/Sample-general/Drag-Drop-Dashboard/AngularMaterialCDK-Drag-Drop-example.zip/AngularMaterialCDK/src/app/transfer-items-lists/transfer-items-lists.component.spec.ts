import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferItemsListsComponent } from './transfer-items-lists.component';

describe('TransferItemsListsComponent', () => {
  let component: TransferItemsListsComponent;
  let fixture: ComponentFixture<TransferItemsListsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferItemsListsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferItemsListsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
