export const ACTIVITIES_COLUMN_DEFS = 'activities-column-defs';
