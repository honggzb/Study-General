export const EMAIL_GROUP = 'email-form';
