import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'crm-command-bar',
  templateUrl: './command-bar.component.html',
  styleUrls: ['./command-bar.component.scss']
})
export class CommandBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
