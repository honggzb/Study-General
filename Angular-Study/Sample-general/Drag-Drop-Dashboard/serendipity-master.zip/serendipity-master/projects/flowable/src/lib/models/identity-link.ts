export interface IdentityLink {

  url?: string;
  user?: string;
  group?: string;
  type?: string;

}
