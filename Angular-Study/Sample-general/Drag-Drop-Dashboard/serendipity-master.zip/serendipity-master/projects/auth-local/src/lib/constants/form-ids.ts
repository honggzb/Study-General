// export const GENERAL_INFORMATION_GROUP = 'general-information-form';
// export const ADDRESS_INFORMATION_GROUP = 'address-information-form';

export const LOGIN_FORM = 'username-password-form';
export const REGISTER_FORM = 'register-form';
