import { DynamicFormControlModel } from './dynamic-form-control.model';

export type DynamicFormModel = DynamicFormControlModel[];
