export const OidcConfigService = 'Oidc Config';
