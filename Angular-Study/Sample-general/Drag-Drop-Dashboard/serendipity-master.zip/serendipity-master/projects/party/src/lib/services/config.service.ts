export const PartyConfigService = 'Sales Config';
