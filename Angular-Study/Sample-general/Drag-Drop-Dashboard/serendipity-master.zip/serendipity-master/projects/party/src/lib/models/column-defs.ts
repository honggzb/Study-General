export const ACCOUNTS_COLUMN_DEFS = 'accounts-column-defs';
export const ACTIVITIES_COLUMN_DEFS = 'activities-column-defs';
export const CONTACTS_COLUMN_DEFS = 'contacts-column-defs';
