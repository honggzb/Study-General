export class Role {

  public id?: string;
  public role?: string;
  public partyId?: string;
  public partyType?: string;
  public partyName?: string;
  public partyEmail?: string;
  public partyPhoneNumber?: string;
  public relationship?: string;
  public reciprocalRole?: string;
  public reciprocalPartyId?: string;
  public reciprocalPartyType?: string;
  public reciprocalPartyName?: string;
  public reciprocalPartyEmail?: string;
  public reciprocalPartyPhoneNumber?: string;

}

// id?: number;
