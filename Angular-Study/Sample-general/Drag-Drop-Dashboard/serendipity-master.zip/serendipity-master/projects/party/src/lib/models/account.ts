import { Organisation } from './organisation';

// tslint:disable-next-line:no-empty-interface
// export interface Account extends Organisation {}
export class Account extends Organisation {}
