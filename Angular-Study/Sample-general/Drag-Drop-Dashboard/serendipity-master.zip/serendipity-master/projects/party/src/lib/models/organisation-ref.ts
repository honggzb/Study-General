import { IndividualRef } from './individual-ref';

// tslint:disable-next-line:no-empty-interface
// export interface Contact extends Individual {}
export class OrganisationRef extends IndividualRef {}
