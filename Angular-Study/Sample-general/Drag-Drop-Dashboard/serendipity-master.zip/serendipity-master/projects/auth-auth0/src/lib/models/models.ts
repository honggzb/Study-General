import { Config } from 'utils';

// tslint:disable-next-line:no-empty-interface
export interface Auth0Config extends Config {}
