import React from 'react';

const ContactPage = () => (
	<div>
		Contact Page
	</div>
)

export default ContactPage;