import styled from 'styled-components';

export const ShopPageContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
