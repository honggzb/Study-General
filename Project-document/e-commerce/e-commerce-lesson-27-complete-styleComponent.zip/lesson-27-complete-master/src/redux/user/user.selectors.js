export const getCurrentUser = state => state.user.currentUser;
