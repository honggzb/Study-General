# robofriends-pwa
adding PWA capabilities to a react app

To run the project:

1. Clone this repo
2. Run `npm install`
3. Run `npm start`

*visist https://zerotomastery.io/ for more*

