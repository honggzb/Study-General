import styled from 'styled-components';

export const ShopPageContainer = styled.div`
  width: 100%;
`;
