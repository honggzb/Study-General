
export const alternatingTexts = [
    {
        heading: "Gut-Friendly Goodness",
        body: "Our soda is packed with prebiotics and 1 billion probiotics, giving your gut the love it deserves. Say goodbye to bloating and hello to a happy, healthy digestive system with every sip."
    },
    {
        heading: "Light Calories, Big Flavor",
        body: "Indulge in bold, refreshing taste without the guilt. At just 20 calories per can, you can enjoy all the flavor you crave with none of the compromise."
    },
    {
        Heading: "Naturally Refreshing",
        body: "Made with only the best natural ingredients, our soda is free from artificial sweeteners and flavors. It’s a crisp, clean taste that feels as good as it tastes, giving you a boost of real, natural refreshment."
    }
];
