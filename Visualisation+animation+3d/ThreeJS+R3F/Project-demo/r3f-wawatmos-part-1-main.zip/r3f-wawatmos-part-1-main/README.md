![Thumbnail video tutorial](https://user-images.githubusercontent.com/6551176/227139129-3a60564c-58d7-4690-87f1-5471a1c202f6.jpg)


[Demo](https://codesandbox.io/p/github/wass08/r3f-wawatmos-part-1)

[Video tutorial](https://youtu.be/WL5zrKii5qc)

[Starter pack](https://github.com/wass08/r3f-wawatmos-starter)


### 3D Model credits

Cloud by Poly by Google [CC-BY](https://creativecommons.org/licenses/by/3.0/) via Poly Pizza (https://poly.pizza/m/44cGXp6_8WD)

Airplane by Poly by Google [CC-BY](https://creativecommons.org/licenses/by/3.0/) via Poly Pizza (https://poly.pizza/m/8VysVKMXN2J)
