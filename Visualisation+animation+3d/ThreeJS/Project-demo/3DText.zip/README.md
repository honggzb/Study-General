## A boilerplate to build R3F projects

## how to use project

1. `npm i`
2. `npm run dev`
3. Open http://localhost:5173 to view it in the browser pages

## install and setup tailwindcss

- [tailwindcss install-using postcss](https://tailwindcss.com/docs/installation/using-postcss)
- `npm i tailwindcss postcss autoprefixer`
- `npx tailwindcss init -p`
   - [Vite PostCSS module error when building app in Svelte](https://stackoverflow.com/questions/73136479/vite-postcss-module-error-when-building-app-in-svelte)
- adding following to 'postcss.config.js' and 'tailwind.config.js'

```javascript
//postcss.config.js
 plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
//tailwind.config.js
content: ["./src/**/*.{html,jsx}"],
```

[⬆ back to top](#top)


=======================================

- [A boilerplate to build R3F projects](#a-boilerplate-to-build-r3f-projects)
- [how to use project](#how-to-use-project)
- [install and setup tailwindcss](#install-and-setup-tailwindcss)
